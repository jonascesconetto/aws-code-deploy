#!/bin/bash
touch /var/www/html/teste.txt
rm -R /var/www/html/*